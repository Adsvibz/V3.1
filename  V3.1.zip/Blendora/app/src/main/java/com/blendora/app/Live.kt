@file:OptIn(ExperimentalMaterial3Api::class)

package com.blendora.app

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
private fun MiniStat(value: Int, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text("$value", color = Color.White, style = MaterialTheme.typography.titleLarge)
        Text(label, color = Color.White.copy(alpha = 0.78f), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun StatCard(label: String, value: Int, color: Color, modifier: Modifier) {
    Panel(modifier) {
        Column(Modifier.padding(vertical = Sp.m).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$value", style = MaterialTheme.typography.headlineSmall, color = color)
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(Sp.m))
        Text(text, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun LiveScreen(act: MainActivity, onMenu: () -> Unit) {
    val c = Store.camp
    val active = Store.campActive()
    val compact = isCompact()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    LaunchedEffect(active) { while (active) { now = System.currentTimeMillis(); delay(500) } }
    val heroList = Store.lists.find { it.id == c.listId }
    val showHero = (active || c.status == CS.FINISHED) && heroList != null

    Scaffold(
        topBar = { BlendBar(T("Live", "التشغيل"), onMenu) },
        bottomBar = { if (active) Controls(compact) },
        containerColor = Color.Transparent
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())
                .padding(horizontal = Sp.xl, vertical = Sp.s),
            verticalArrangement = Arrangement.spacedBy(Sp.l)
        ) {
            PermissionBanner(act)
            if (showHero && heroList != null) {
                val p = Store.prog(heroList)
                Hero(c, p, now, compact)
                if (c.status == CS.FINISHED) Banner(if (c.error) Tk.ERROR else Tk.SUCCESS, c.message)
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.m), modifier = Modifier.fillMaxWidth()) {
                    StatCard(T("Answered", "ردّوا"), p.answered, Sem.success, Modifier.weight(1f))
                    StatCard(T("No answer", "لم يردّوا"), p.noAnswer, Sem.warning, Modifier.weight(1f))
                    StatCard(T("Failed", "فشل"), p.failed, Sem.danger, Modifier.weight(1f))
                }
                if (active && !Store.cfg.shuffle) UpNext(heroList)
            }
            if (!active) {
                if (c.status == CS.FINISHED && heroList != null && !c.error) {
                    BButton(T("View campaign results", "عرض نتائج الحملة"),
                        { Store.resultsListId = c.listId; Store.tab = 2 }, Modifier.fillMaxWidth(),
                        kind = BtnKind.Tonal, icon = Icons.Rounded.BarChart)
                }
                Launcher(act)
            }
            Spacer(Modifier.height(Sp.l))
        }
    }
}

@Composable
private fun Hero(c: CampState, p: Prog, now: Long, compact: Boolean) {
    val finished = c.status == CS.FINISHED
    val calling = c.status == CS.RUNNING && c.currentNumber.isNotEmpty()
    val secs = if (c.nextAt > now) ((c.nextAt - now + 999) / 1000).toInt() else 0

    val label = when {
        finished -> if (c.error) T("Stopped", "توقفت") else T("Finished", "انتهت")
        c.status == CS.PAUSED -> T("Paused", "متوقفة")
        c.status == CS.WAITING -> T("Waiting", "في الانتظار")
        calling -> T("Calling now", "جارٍ الاتصال")
        c.awaitingStage -> T("Your input", "بانتظارك")
        else -> T("Next call", "الاتصال التالي")
    }
    val big = when {
        calling -> c.currentName.ifBlank { c.currentNumber }
        finished -> c.message
        c.status == CS.PAUSED -> T("Paused", "متوقفة مؤقتًا")
        c.awaitingStage -> T("Choose the call result", "اختر نتيجة المكالمة")
        c.status == CS.WAITING -> T("Waiting", "في الانتظار")
        secs > 0 -> "${secs}s"
        else -> c.message.ifBlank { "…" }
    }
    val small = when {
        calling && c.currentName.isNotBlank() -> c.currentNumber
        finished -> T("${p.answered} answered · ${p.noAnswer} no answer · ${p.failed} failed",
            "${p.answered} ردّوا · ${p.noAnswer} لم يردّوا · ${p.failed} فشل")
        c.status == CS.PAUSED -> T("Tap Resume to continue", "اضغط استئناف للمتابعة")
        c.awaitingStage && secs > 0 -> T("Continuing in ${secs}s", "المتابعة بعد ${secs} ث")
        c.status == CS.WAITING -> c.message
        secs > 0 -> c.message
        else -> ""
    }

    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.xl)).background(Brand).padding(Sp.xxl)) {
        Column(verticalArrangement = Arrangement.spacedBy(Sp.l), modifier = Modifier.fillMaxWidth()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (finished) Icon(Icons.Rounded.CheckCircle, null, tint = Color.White, modifier = Modifier.size(16.dp))
                else PulseDot(Color.White, 8.dp)
                Spacer(Modifier.width(Sp.s))
                Text(label, color = Color.White.copy(alpha = 0.92f), style = MaterialTheme.typography.labelLarge)
                Spacer(Modifier.weight(1f))
                Text(c.listName, color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.labelLarge,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 160.dp))
            }
            Column(verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                Text(big, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = if (compact) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.headlineMedium)
                if (small.isNotEmpty()) {
                    if (calling && c.currentName.isNotBlank()) NumText(small, color = Color.White.copy(alpha = 0.88f),
                        style = MaterialTheme.typography.titleMedium)
                    else Text(small, color = Color.White.copy(alpha = 0.82f), style = MaterialTheme.typography.bodyMedium)
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                ProgressRing(p.pct / 100f, 84.dp, 8.dp, Color.White, Color.White.copy(alpha = 0.25f)) {
                    Text("${p.pct}%", color = Color.White, style = MaterialTheme.typography.titleMedium)
                }
                Spacer(Modifier.width(Sp.xl))
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                    MiniStat(p.total, T("Total", "الإجمالي"))
                    MiniStat(p.called, T("Called", "تم الاتصال"))
                    MiniStat(p.remaining, T("Left", "المتبقي"))
                }
            }
            if (c.loops > 1) Text(T("Round ${c.loop} of ${c.loops}", "الجولة ${c.loop} من ${c.loops}"),
                color = Color.White.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun UpNext(list: CallList) {
    val next = list.entries.filter { it.status == St.PENDING }.take(3)
    if (next.isNotEmpty()) {
        Panel(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                SectionLabel(T("Up next", "التالي"))
                next.forEach { e ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Avatar(e.name.ifBlank { e.number }, size = 34.dp)
                        Spacer(Modifier.width(Sp.m))
                        Column {
                            Text(e.name.ifBlank { e.number }, style = MaterialTheme.typography.titleSmall, maxLines = 1,
                                overflow = TextOverflow.Ellipsis)
                            if (e.name.isNotBlank()) NumText(e.number, style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Controls(compact: Boolean) {
    val c = Store.camp
    val ctx = LocalContext.current
    Surface(color = MaterialTheme.colorScheme.surface, shadowElevation = 10.dp) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m),
            horizontalArrangement = Arrangement.spacedBy(Sp.s)
        ) {
            if (c.status == CS.PAUSED)
                BButton(T("Resume", "استئناف"), { DialerService.send(ctx, DialerService.ACT_RESUME) }, Modifier.weight(1.4f),
                    icon = Icons.Rounded.PlayArrow, compact = true)
            else
                BButton(T("Pause", "إيقاف مؤقت"), { DialerService.send(ctx, DialerService.ACT_PAUSE) }, Modifier.weight(1.4f),
                    kind = BtnKind.Tonal, icon = Icons.Rounded.Pause, compact = true)
            BButton(T("End call", "إنهاء"), { DialerService.send(ctx, DialerService.ACT_SKIP) }, Modifier.weight(1f),
                kind = BtnKind.Outline, icon = Icons.Rounded.SkipNext, compact = true, iconOnly = compact)
            BButton(T("Stop", "إيقاف"), { DialerService.send(ctx, DialerService.ACT_STOP) }, Modifier.weight(1f),
                kind = BtnKind.Danger, icon = Icons.Rounded.Stop, compact = true, iconOnly = compact)
        }
    }
}

@Composable
private fun Launcher(act: MainActivity) {
    val sel = Store.runListId?.takeIf { id -> Store.lists.any { it.id == id } } ?: Store.lists.firstOrNull()?.id
    val selList = Store.lists.find { it.id == sel }
    val p = selList?.let { Store.prog(it) }

    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
            SectionLabel(T("Choose a campaign", "اختر الحملة"))
            if (Store.lists.isEmpty()) {
                Text(T("Create a campaign first.", "أنشئ حملة أولاً."), color = MaterialTheme.colorScheme.onSurfaceVariant)
                BButton(T("Go to campaigns", "الذهاب إلى الحملات"), { Store.tab = 0 }, kind = BtnKind.Tonal, compact = true)
            }
            Store.lists.forEach { l ->
                val lp = Store.prog(l)
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(Rd.m)).clickable { Store.runListId = l.id }
                        .background(if (l.id == sel) MaterialTheme.colorScheme.primary.copy(alpha = 0.08f) else Color.Transparent)
                        .padding(horizontal = Sp.s, vertical = Sp.xs),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RadioButton(selected = l.id == sel, onClick = { Store.runListId = l.id })
                    Column(Modifier.weight(1f)) {
                        Text(l.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(T("${lp.total} contacts · ${lp.remaining} left", "${lp.total} جهة · ${lp.remaining} متبقي"),
                            style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    if (sel != null && p != null && p.total > 0) {
        val resumable = p.called > 0 && p.remaining > 0
        BButton(
            when {
                resumable -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي")
                p.called > 0 -> T("Restart campaign", "إعادة تشغيل الحملة")
                else -> T("Start campaign", "ابدأ الحملة")
            },
            { act.startCampaign(sel, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow
        )
        if (resumable) {
            BButton(T("Restart from the beginning", "ابدأ من الأول"), { act.startCampaign(sel, true) },
                Modifier.fillMaxWidth(), kind = BtnKind.Outline, icon = Icons.Rounded.Refresh)
        }
    }

    val s = Store.cfg
    Panel(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(Sp.l), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionLabel(T("Run setup", "إعدادات التشغيل"), Modifier.weight(1f))
                TextButton(onClick = { Store.openSettings() }) { Text(T("Change", "تعديل")) }
            }
            val gap = if (s.randomDelay) "${s.delaySec}–${s.delayMaxSec}s" else "${s.delaySec}s"
            InfoRow(Icons.Rounded.Timer, T("Delay between calls: $gap", "الانتظار بين المكالمات: $gap"))
            InfoRow(Icons.Rounded.Replay, T("Retries: ${s.retries} · Rounds: ${s.loops}", "إعادة المحاولة: ${s.retries} · الجولات: ${s.loops}"))
            InfoRow(Icons.Rounded.VolumeUp, T("Speaker & muted mic: ${if (s.autoSpeaker) "on" else "off"}",
                "السماعة وكتم المايك: ${if (s.autoSpeaker) "مفعّل" else "مغلق"}"))
        }
    }
}
