@file:OptIn(ExperimentalMaterial3Api::class)

package com.blendora.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private fun reportAdded(n: Int) {
    if (n > 0) Store.notify(Tk.SUCCESS, T("$n numbers added", "تمت إضافة $n رقم"))
    else Store.notify(Tk.INFO, T("No new numbers (duplicates or invalid)", "لا أرقام جديدة (مكررة أو غير صالحة)"))
}

@Composable
private fun Legend(color: Color, text: String) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ============================================================ campaigns list
@Composable
fun ListsScreen(onMenu: () -> Unit) {
    var creating by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<CallList?>(null) }
    var deleting by remember { mutableStateOf<CallList?>(null) }

    Scaffold(
        topBar = {
            BlendBar(T("Campaigns", "الحملات"), onMenu,
                subtitle = if (Store.lists.isEmpty()) null else T("${Store.lists.size} campaigns", "${Store.lists.size} حملة"))
        },
        floatingActionButton = {
            if (Store.lists.isNotEmpty()) ExtendedFloatingActionButton(
                onClick = { creating = true }, shape = RoundedCornerShape(Rd.l),
                containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Rounded.Add, null) },
                text = { Text(T("New campaign", "حملة جديدة"), style = MaterialTheme.typography.labelLarge) }
            )
        },
        containerColor = Color.Transparent
    ) { pad ->
        if (Store.lists.isEmpty()) {
            EmptyState(Icons.Rounded.Campaign, T("No campaigns yet", "لا توجد حملات بعد"),
                T("Create a campaign, add your contacts and start calling.", "أنشئ حملة وأضف جهات الاتصال وابدأ الاتصال."),
                Modifier.padding(pad), actionText = T("Create campaign", "إنشاء حملة"), onAction = { creating = true })
        } else {
            LazyColumn(Modifier.padding(pad), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, 110.dp),
                verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                items(Store.lists, key = { it.id }) { l ->
                    CampaignCard(l, onOpen = { Store.selectedListId = l.id }, onEdit = { editing = l }, onDelete = { deleting = l })
                }
            }
        }
    }

    if (creating) CampaignDialog(null, { creating = false }) { n, sim ->
        Store.selectedListId = Store.addList(n, sim); creating = false
        Store.notify(Tk.SUCCESS, T("Campaign created", "تم إنشاء الحملة"))
    }
    editing?.let { l ->
        CampaignDialog(l, { editing = null }) { n, sim ->
            Store.updateList(l.id) { it.copy(name = n, simSlot = sim) }; editing = null
            Store.notify(Tk.SUCCESS, T("Campaign updated", "تم تحديث الحملة"))
        }
    }
    deleting?.let { l ->
        ConfirmDialog(T("Delete \"${l.name}\" and all its numbers?", "حذف \"${l.name}\" وكل أرقامها؟"), { deleting = null }) {
            Store.deleteList(l.id); deleting = null
            Store.notify(Tk.INFO, T("Campaign deleted", "تم حذف الحملة"))
        }
    }
}

@Composable
fun CampaignCard(l: CallList, onOpen: () -> Unit, onEdit: () -> Unit, onDelete: () -> Unit) {
    val ctx = LocalContext.current
    val p = Store.prog(l)
    var menu by remember { mutableStateOf(false) }
    val sim = when (l.simSlot) { 0 -> "SIM 1"; 1 -> "SIM 2"; else -> T("Default SIM", "الشريحة الافتراضية") }
    val running = Store.campActive() && Store.camp.listId == l.id
    val grey = MaterialTheme.colorScheme.onSurfaceVariant
    val st = when {
        running -> Triple(T("Running", "قيد التشغيل"), Sem.success, Icons.Rounded.PlayArrow)
        p.total == 0 -> Triple(T("Empty", "فارغة"), grey, Icons.Rounded.Info)
        p.called == 0 -> Triple(T("Not started", "لم تبدأ"), grey, Icons.Rounded.Schedule)
        p.remaining > 0 -> Triple(T("In progress", "جارية"), Sem.info, Icons.Rounded.Replay)
        else -> Triple(T("Completed", "مكتملة"), Sem.success, Icons.Rounded.CheckCircle)
    }

    Panel(Modifier.fillMaxWidth(), onClick = onOpen) {
        Column(Modifier.padding(Sp.l)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Rounded.Campaign)
                Spacer(Modifier.width(Sp.m))
                Column(Modifier.weight(1f)) {
                    Text(l.name, style = MaterialTheme.typography.titleMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${p.total} " + T("contacts", "جهة اتصال") + "  •  " + sim,
                        style = MaterialTheme.typography.labelMedium, color = grey, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box {
                    IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null) }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(text = { Text(T("Edit campaign", "تعديل الحملة")) },
                            leadingIcon = { Icon(Icons.Rounded.Edit, null) }, onClick = { menu = false; onEdit() })
                        DropdownMenuItem(text = { Text(T("View results", "عرض النتائج")) },
                            leadingIcon = { Icon(Icons.Rounded.BarChart, null) },
                            onClick = { menu = false; Store.resultsListId = l.id; Store.tab = 2 })
                        DropdownMenuItem(text = { Text(T("Reset progress", "إعادة ضبط التقدم")) },
                            leadingIcon = { Icon(Icons.Rounded.Refresh, null) },
                            onClick = {
                                menu = false; Store.resetForRestart(l.id, false)
                                Store.notify(Tk.SUCCESS, T("Progress reset", "تمت إعادة الضبط"))
                            })
                        DropdownMenuItem(text = { Text(T("Remove duplicates", "حذف المكرر")) },
                            leadingIcon = { Icon(Icons.Rounded.ContentPaste, null) },
                            onClick = {
                                menu = false
                                val removed = Store.dedupe(l.id)
                                Store.notify(Tk.SUCCESS, T("Removed $removed duplicates", "تم حذف $removed مكرر"))
                            })
                        DropdownMenuItem(text = { Text(T("Share report", "مشاركة التقرير")) },
                            leadingIcon = { Icon(Icons.Rounded.Share, null) },
                            onClick = { menu = false; shareText(ctx, Store.listReport(l)) })
                        DropdownMenuItem(text = { Text(T("Delete", "حذف"), color = Sem.danger) },
                            leadingIcon = { Icon(Icons.Rounded.Delete, null, tint = Sem.danger) },
                            onClick = { menu = false; onDelete() })
                    }
                }
            }
            if (p.total > 0) {
                Spacer(Modifier.height(Sp.l))
                BProgress(p.pct / 100f, color = if (p.remaining == 0) Sem.success else MaterialTheme.colorScheme.primary, height = 6.dp)
                Spacer(Modifier.height(Sp.m))
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Pill(st.first, st.second, st.third)
                    Spacer(Modifier.weight(1f))
                    Text(T("${p.pct}% • ${p.answered} answered", "${p.pct}% • ${p.answered} ردّوا"),
                        style = MaterialTheme.typography.labelMedium, color = grey)
                }
            } else {
                Spacer(Modifier.height(Sp.m))
                Pill(st.first, st.second, st.third)
            }
        }
    }
}

// ============================================================ campaign contacts
@Composable
fun ListDetail(listId: String, act: MainActivity) {
    val list = Store.lists.find { it.id == listId }
    if (list == null) { LaunchedEffect(Unit) { Store.selectedListId = null }; return }
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var query by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf("") }
    var importing by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            importing = true
            scope.launch {
                val text = withContext(Dispatchers.IO) {
                    runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull() ?: ""
                }
                val parsed = parseLines(text)
                val n = Store.addEntries(listId, parsed)
                importing = false
                if (parsed.isEmpty()) Store.notify(Tk.ERROR, T("No valid numbers found in the file", "لم يتم العثور على أرقام صالحة في الملف"))
                else reportAdded(n)
            }
        }
    }
    val p = Store.prog(list)
    val shown = list.entries.filter { query.isBlank() || it.name.contains(query, true) || it.number.contains(query) }
    val simText = when (list.simSlot) { 0 -> "SIM 1"; 1 -> "SIM 2"; else -> T("Default SIM", "الشريحة الافتراضية") }

    val chips: @Composable () -> Unit = {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(Sp.s)) {
            ActionChip(Icons.Rounded.Add, T("Add number", "إضافة رقم")) { dlg = "add" }
            ActionChip(Icons.Rounded.ContentPaste, T("Paste", "لصق")) { dlg = "bulk" }
            ActionChip(Icons.Rounded.UploadFile, "CSV / TXT") { importer.launch(arrayOf("*/*")) }
            ActionChip(Icons.Rounded.Contacts, T("Contacts", "جهات الاتصال")) { act.ensureContacts { dlg = "contacts" } }
        }
    }

    Scaffold(
        topBar = {
            BlendBar(list.name, null, onBack = { Store.selectedListId = null },
                subtitle = T("${p.total} contacts · $simText", "${p.total} جهة · $simText"))
        },
        bottomBar = {
            if (list.entries.isNotEmpty()) {
                val label = when {
                    p.called == 0 -> T("Start campaign", "ابدأ الحملة")
                    p.remaining > 0 -> T("Resume · ${p.remaining} left", "استئناف · ${p.remaining} متبقي")
                    else -> T("Restart campaign", "إعادة تشغيل الحملة")
                }
                Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = Sp.xl, vertical = Sp.m)) {
                    BButton(label, { act.startCampaign(listId, p.called > 0 && p.remaining == 0) }, Modifier.fillMaxWidth(),
                        icon = Icons.Rounded.PlayArrow)
                }
            }
        },
        containerColor = Color.Transparent
    ) { pad ->
        if (list.entries.isEmpty()) {
            Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = Sp.xl), verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                PermissionBanner(act)
                chips()
                if (importing) LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(50)))
                EmptyState(Icons.Rounded.Groups, T("No contacts yet", "لا توجد أرقام"),
                    T("Add numbers manually, paste them, import a CSV/TXT file or pick from your contacts.",
                        "أضف الأرقام يدويًا أو بالصق أو من ملف CSV/TXT أو من جهات الاتصال."))
            }
        } else {
            LazyColumn(Modifier.padding(pad).fillMaxSize(), contentPadding = PaddingValues(Sp.xl, Sp.s, Sp.xl, Sp.xl),
                verticalArrangement = Arrangement.spacedBy(Sp.m)) {
                item { PermissionBanner(act) }
                if (importing) item { LinearProgressIndicator(Modifier.fillMaxWidth().clip(RoundedCornerShape(50))) }
                item { SummaryPanel(p) }
                item { chips() }
                item {
                    BTextField(query, { query = it }, placeholder = T("Search name or number", "بحث بالاسم أو الرقم"),
                        leading = Icons.Rounded.Search)
                }
                if (shown.isEmpty()) item {
                    Text(T("No matches", "لا نتائج"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                items(shown, key = { it.id }) { e -> EntryRow(e, listId) { editing = e } }
            }
        }
    }

    when (dlg) {
        "add" -> EntryDialog(null, { dlg = "" }) { n, num -> reportAdded(Store.addEntries(listId, listOf(n to num))); dlg = "" }
        "bulk" -> BulkDialog({ dlg = "" }) { t -> reportAdded(Store.addEntries(listId, parseLines(t))); dlg = "" }
        "contacts" -> ContactsDialog({ dlg = "" }) { sel -> reportAdded(Store.addEntries(listId, sel)); dlg = "" }
    }
    editing?.let { e ->
        EntryDialog(e, { editing = null }) { n, num ->
            Store.editEntry(listId, e.id, n, num); editing = null
            Store.notify(Tk.SUCCESS, T("Contact updated", "تم تحديث الجهة"))
        }
    }
}

@Composable
private fun SummaryPanel(p: Prog) {
    Panel(Modifier.fillMaxWidth()) {
        Row(Modifier.padding(Sp.l), verticalAlignment = Alignment.CenterVertically) {
            ProgressRing(p.pct / 100f, 72.dp, 7.dp, MaterialTheme.colorScheme.primary, MaterialTheme.colorScheme.outline) {
                Text("${p.pct}%", style = MaterialTheme.typography.titleSmall)
            }
            Spacer(Modifier.width(Sp.l))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.s)) {
                Text(T("${p.called} of ${p.total} called", "${p.called} من ${p.total} تم الاتصال"), style = MaterialTheme.typography.titleSmall)
                Row(horizontalArrangement = Arrangement.spacedBy(Sp.m)) {
                    Legend(Sem.success, T("${p.answered} answered", "${p.answered} ردّوا"))
                    Legend(Sem.warning, T("${p.noAnswer} no answer", "${p.noAnswer} لم يردّوا"))
                }
                Legend(Sem.danger, T("${p.failed} failed", "${p.failed} فشل"))
            }
        }
    }
}

@Composable
fun EntryRow(e: Entry, listId: String, onEdit: () -> Unit) {
    val answered = St.isAnswered(e.status)
    Panel(Modifier.fillMaxWidth(), onClick = onEdit) {
        Row(Modifier.padding(Sp.m), verticalAlignment = Alignment.CenterVertically) {
            Avatar(e.name.ifBlank { e.number }, if (e.stage != Stg.NONE) Stg.color(e.stage) else MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(Sp.m))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(Sp.xs)) {
                if (e.name.isNotBlank()) {
                    Text(e.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NumText(e.number,
                        style = if (e.name.isBlank()) MaterialTheme.typography.titleSmall else MaterialTheme.typography.bodySmall,
                        color = if (e.name.isBlank()) Color.Unspecified else MaterialTheme.colorScheme.onSurfaceVariant)
                    if (answered && e.duration > 0) {
                        Spacer(Modifier.width(Sp.s))
                        Pill(fmtDur(e.duration), Sem.success, Icons.Rounded.Schedule)
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    if (e.status != St.PENDING) StatusPill(e.status)
                    if (e.stage != Stg.NONE) StagePill(e.stage) { Store.stageTarget = listId to e.id }
                    else if (answered) Pill(T("+ Stage", "+ نتيجة"), MaterialTheme.colorScheme.primary) { Store.stageTarget = listId to e.id }
                }
            }
            if (e.stage != Stg.NONE) {
                WhatsAppButton(e.number)
                Spacer(Modifier.width(Sp.xs))
            }
            IconButton(onClick = { Store.deleteEntry(listId, e.id) }) {
                Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
