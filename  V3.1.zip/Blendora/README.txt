Blendora v3.0
Upload Blendora.zip as-is to your GitHub repo root, keep .github/workflows/build.yml (unzips Blendora*.zip), run Actions, download Blendora-APK.
